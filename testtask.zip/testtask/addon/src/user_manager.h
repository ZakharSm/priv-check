#ifndef USER_MANAGER_H
#define USER_MANAGER_H

#include <Windows.h>

extern napi_value CheckUserPrivileges(napi_env env, napi_value argv, napi_value context);

#endif
