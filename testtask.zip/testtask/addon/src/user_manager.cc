#include <node_api.h>
#include <Windows.h>

#define CHECK_HR(hr, message) \
  if (FAILED(hr)) { \
    node_error(message); \
    return nullptr; \
  }

// Функция для проверки привилегий пользователя
static napi_value CheckUserPrivileges(napi_env env, napi_value argv, napi_value context) {
  // Получение имени пользователя из аргумента
  char username[256] = {0};
  size_t usernameLen = sizeof(username);
  napi_get_string(env, argv[0], username, &usernameLen, NULL);

  // Получение SID пользователя
  HANDLE hToken = NULL;
  LSA_TOKEN_INFORMATION tokenInfo;

  BOOL success = OpenProcessToken(GetCurrentProcess(), TOKEN_READ, &hToken);
  CHECK_HR(success, "OpenProcessToken failed");

  DWORD dwReturnLength = sizeof(tokenInfo);
  success = GetTokenInformation(hToken, TokenInformation, &tokenInfo, dwReturnLength, &dwReturnLength);
  CHECK_HR(success, "GetTokenInformation failed");

  PSID userSid = tokenInfo.Sid;

  // Проверка привилегий пользователя
  BOOL isAdmin = FALSE;
  BOOL isUser = FALSE;
  BOOL isGuest = FALSE;

  SID_IDENTIFIER_AUTHORITY ntAuth = SECURITY_NT_AUTHORITY;
  SID_IDENTIFIER_RID adminsRid = RIDL_ADMINS_RID;
  SID_IDENTIFIER_RID usersRid = RIDL_USERS_RID;
  SID_IDENTIFIER_RID guestsRid = RIDL_GUESTS_RID;

  SID_ASTERICK sidAsterisk = {};
  SID_STRUCT sidStruct = {1, 1, &ntAuth, 0, 0, 0, 0};
  SID_IDENTIFIER_AND sidAnd = {userSid, &sidStruct};

  // Проверка администратора
  success = CheckTokenMembership(hToken, &sidAnd, &isAdmin);
  CHECK_HR(success, "CheckTokenMembership failed");

  // Проверка пользователя
  sidStruct.SidIdentifier.Rid = usersRid;
  sidAnd.Sid = &sidStruct;
  success = CheckTokenMembership(hToken, &sidAnd, &isUser);
  CHECK_HR(success, "CheckTokenMembership failed");

  // Проверка гостя
  sidStruct.SidIdentifier.Rid = guestsRid;
  sidAnd.Sid = &sidStruct;
  success = CheckTokenMembership(hToken, &sidAnd, &isGuest);
  CHECK_HR(success, "CheckTokenMembership failed");

  // Формирование сообщения
  char message[256] = {0};

  if (isAdmin) {
    sprintf(message, "Пользователь %s имеет привилегию Администратор", username);
  } else if (isUser) {
    sprintf(message, "Пользователь %s имеет привилегию Пользователь", username);
  } else if (isGuest) {
    sprintf(message, "Пользователь %s имеет привилегию Гость", username);
  } else {
    sprintf(message, "Пользователя %s нет", username);
  }

  // Возвращение сообщения в JavaScript-код
  napi_value result;
  napi_create_string_utf8(env, message, strlen(message), &result);

  CloseHandle(hToken);

  return result;
}

// Регистрация функции в Node.js API
NAPI_INIT(init) {
  Napi_Value exports;
  Napi_Exports(env, &exports, 1, &CheckUserPrivileges);
  return exports;
}
