const express = require('express');
const bodyParser = require('body-parser');
const addon = require('./addon');

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: false }));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/src/index.html');
});

app.post('/check-user', async (req, res) => {
  const username = req.body.username;
  const result = await addon.CheckUserPrivileges(username);
  res.json({ message: result });
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
